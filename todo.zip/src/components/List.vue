<template>
  <div>
    <ul class="tasks-list">
      <Task
        :todos="todos"
        v-on:create-task="onSubmit"
      ></Task>
    </ul>
  </div>
</template>

<script>
import Task from '@/components/Task.vue';

export default {
  name: 'List',
  data() {
    return {
      todos: [
        { id: 1, title: 'Море волнуется раз', completed: false },
        { id: 2, title: 'Море волнуется два', completed: true },
        { id: 3, title: 'Море волнуется три', completed: false },
      ],
    };
  },
  methods: {
    removeTask(id) {
      // this.$emit('removeTask', id);
      this.todos = this.todos.filter((i) => i.id !== id);
    },
    onSubmit(todo) {
      this.todos.push(todo);
    },
  },
  components: {
    Task,
  },
};
</script>

<style scoped>
.tasks-list {
  list-style: none;

  width: 100%;
  box-sizing: border-box;

  margin: 0;
  padding: 10px;
}
</style>
