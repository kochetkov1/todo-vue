<template>
  <div class="task-container">
    <li
      v-for="todo of todos"
      :key="todo.id"
      class="task"
    >
      <div>
        <el-checkbox name="type"
                     v-model="todo.completed"></el-checkbox>
        <span class="task-title">{{ todo.title }}</span>
      </div>
      <el-button size="mini" type="primary" icon="el-icon-delete"
                 v-on:click="$emit('remove-task', todo.id)"></el-button>
    </li>
  </div>
</template>

<script>
export default {
  name: 'Task',
  props: {
    todos: [],
  },
};
</script>

<style scoped>
.task-container {
  width: 480px;
}

.task {
  width: 100%;
  margin: 10px;

  display: flex;
  align-items: flex-start;
  justify-content: space-between;
}

.task-title {
  margin: 0 0 0 10px;
  font-size: 18px;
}
</style>
